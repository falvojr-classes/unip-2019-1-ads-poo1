﻿using System;

namespace Exercicio01
{
    class Agencia
    {
        public String Nome { get; set; }
        public long Numero { get; set; }
    }
}
