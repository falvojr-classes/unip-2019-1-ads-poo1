﻿namespace Exercicio01
{
    class Cartao
    {
        public long Numero { get; set; }
        public double Saldo { get; set; }
        public double Limite { get; set; }
        // Atributo que relaciona o Cliente com o Cartao (1 para N)
        public Cliente Cliente { get; set; }
    }
}
