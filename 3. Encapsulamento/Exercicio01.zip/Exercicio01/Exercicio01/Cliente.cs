﻿using System;

namespace Exercicio01
{
    class Cliente
    {
        public String Nome { get; set; }
        public String Documento { get; set; }
    }
}
