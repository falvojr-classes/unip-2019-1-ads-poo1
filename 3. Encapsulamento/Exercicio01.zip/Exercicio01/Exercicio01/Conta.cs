﻿using System;

namespace Exercicio01
{
    class Conta
    {
        public long Numero { get; set; }
        public double Saldo { get; set; }
        public double Limite { get; set; }
        public Cliente Cliente { get; set; }
        public Agencia Agencia { get; set; }
        
        public Conta()
        {
            this.Limite = 500;
        }

        public Conta(double limite)
        {
            this.Limite = limite;
        }
        
        public void ImprimirExtrato()
        {
            Console.WriteLine(this.Cliente.Nome);
            Console.WriteLine("Saldo: {0:0.00}", this.Saldo);
            Console.WriteLine("Limite: {0:0.00}", this.Limite);
        }
        
        public void Depositar(double valor)
        {
            this.Saldo += valor;
        }
        
        public void Sacar(double valor)
        {
            this.Sacar(valor, 0.5);
        }
        
        public void Sacar(double valor, double taxa)
        {
            this.Saldo -= (valor + taxa);
        }
    }
}
