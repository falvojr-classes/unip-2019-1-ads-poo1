﻿using System;

namespace Exercicio01
{
    class Teste
    {
        static void Main(string[] args)
        {
            Agencia agenciaAra = new Agencia();
            agenciaAra.Nome = "Araraquara";

            Cliente venilton = new Cliente();
            venilton.Nome = "Venilton";

            Conta contaCorrente = new Conta();
            contaCorrente.Numero = 1;
            contaCorrente.Agencia = agenciaAra;
            contaCorrente.Cliente = venilton;

            Cartao cartao = new Cartao();
            cartao.Numero = 12345678123456789;
            cartao.Cliente = venilton;

            contaCorrente.Depositar(1000);
            contaCorrente.Sacar(100);
            contaCorrente.Sacar(100, 5);
            contaCorrente.ImprimirExtrato();

            Console.ReadKey();
        }
    }
}
