﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio01
{
    class Program
    {
        static void Main(string[] args)
        {
            Gato gato = new Gato();
            Passaro passaro = new Passaro();
            Cachorro cachorro = new Cachorro();

            gato.EmitirSom();
            passaro.EmitirSom();
            cachorro.EmitirSom();

            Console.ReadKey();
        }
    }
}
