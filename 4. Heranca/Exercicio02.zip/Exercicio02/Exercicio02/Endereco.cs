﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02
{
    public class Endereco
    {
        public string Logradouro { get; private set; }
        public string Cep { get; set; }
        public string Complemento { get; private set; }

        public void Preencher()
        {
            this.Logradouro = "Av. Paulino Rodella, 1234";
            this.Complemento = "Bloco 16, Apartamento 104";
        }
    }
}
