﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02
{
    public class PF : Pessoa
    {
        public string Cpf { get; set; }
        public DateTime DataNascimento { get; set; }

        public override void Imprimir()
        {
            Console.WriteLine(this.Cpf);
            base.Imprimir();
        }
    }
}
