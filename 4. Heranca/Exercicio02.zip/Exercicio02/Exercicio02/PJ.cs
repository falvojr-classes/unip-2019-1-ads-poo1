﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02
{
    public class PJ : Pessoa
    {
        public string Cnpj { get; set; }

        public override void Imprimir()
        {
            Console.WriteLine(this.Cnpj);
            base.Imprimir();
        }
    }
}
