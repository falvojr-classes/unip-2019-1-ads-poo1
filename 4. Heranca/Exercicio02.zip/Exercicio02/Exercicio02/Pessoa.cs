﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02
{
    public abstract class Pessoa
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public Endereco Endereco { get; set; }

        public Pessoa()
        {
            this.Endereco = new Endereco();
        }

        public virtual void Imprimir()
        {
            Console.WriteLine(this.Nome);
            Console.WriteLine(this.Endereco.Logradouro);
            Console.WriteLine(this.Endereco.Complemento);
        }
    }
}
