﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            PJ pj = new PJ();
            pj.Nome = "UNIP";
            pj.Cnpj = "22.000.000/0001-1";

            // Simulando o consumo de um servico dos Correios
            pj.Endereco.Cep = "14801-788";
            pj.Endereco.Preencher();

            // Imprime os dados da PJ
            pj.Imprimir();

            PF pf = new PF();
            pf.Nome = "Venilton";
            pf.Cpf = "333.333.333-33";
            pf.Endereco.Cep = "14801-788";
            pf.Endereco.Preencher();

            // Imprime os dados da PF
            pf.Imprimir();

            Console.ReadKey();
        }
    }
}
