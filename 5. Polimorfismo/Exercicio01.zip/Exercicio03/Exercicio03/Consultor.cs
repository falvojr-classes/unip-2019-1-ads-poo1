﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio03
{
    public class Consultor : Funcionario
    {
        public double ValorHora { get; set; }
        public long HorasTrabalhadas { get; set; }

        public override double CalcularSalario()
        {
            return ValorHora * HorasTrabalhadas;
        }
    }
}
