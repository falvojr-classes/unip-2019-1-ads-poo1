﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio03
{
    public abstract class Funcionario
    {
        protected const double SalarioMinimo = 998;

        public String Nome { get; set; }
        public String Cpf { get; set; }

        public abstract double CalcularSalario();
    }
}
