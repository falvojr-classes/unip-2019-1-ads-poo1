﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio03
{
    public class Ponto
    {
        public void RegistrarEntrada(Funcionario funcionario)
        {
            Imprimir(funcionario, true);
        }

        public void RegistrarSaida(Funcionario funcionario)
        {
            Imprimir(funcionario, false);
        }

        private void Imprimir(Funcionario funcionario, bool ehEntrada)
        {
            String tipoComprovante = ehEntrada ? "Entrada" : "Saida";

            Console.WriteLine("Comprovante de {0}", tipoComprovante);
            Console.WriteLine("Nome: {0}", funcionario.Nome);
            if (funcionario is Vendedor)
            {
                Console.WriteLine("Tipo: Vendedor");
            }
            else if (funcionario is Gerente)
            {
                Console.WriteLine("Tipo: Gerente");
            }
            else if (funcionario is Consultor)
            {
                Console.WriteLine("Tipo: Consultor");
            }
            Console.WriteLine("Data: {0:d/M/yyyy HH:mm:ss}", DateTime.Now);
            Console.WriteLine();
        }
    }
}
