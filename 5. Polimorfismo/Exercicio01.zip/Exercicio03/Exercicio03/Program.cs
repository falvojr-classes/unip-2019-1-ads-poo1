﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio03
{
    class Program
    {
        static void Main(string[] args)
        {
            Vendedor vendedor = new Vendedor();
            vendedor.Nome = "Alan";
            vendedor.Comissao = 50;
            vendedor.NumeroVendas = 300;

            Gerente gerente = new Gerente();
            gerente.Nome = "Joao Silva";
            gerente.Bonificacao = 0;

            Consultor consultor = new Consultor();
            consultor.Nome = "Silvio";
            consultor.ValorHora = 60;
            consultor.HorasTrabalhadas = 80;

            Ponto controlePonto = new Ponto();

            // Simulando entrada dos Funcionarios
            controlePonto.RegistrarEntrada(vendedor);
            controlePonto.RegistrarEntrada(consultor);
            controlePonto.RegistrarEntrada(gerente);

            // Simulando saida dos Funcionarios
            controlePonto.RegistrarSaida(vendedor);
            controlePonto.RegistrarSaida(consultor);
            controlePonto.RegistrarSaida(gerente);

            Console.WriteLine(vendedor.CalcularSalario());
            Console.WriteLine(gerente.CalcularSalario());
            Console.WriteLine(consultor.CalcularSalario());
            Console.ReadKey();
        }
    }
}
