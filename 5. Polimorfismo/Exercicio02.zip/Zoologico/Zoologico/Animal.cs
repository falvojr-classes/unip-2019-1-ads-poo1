﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    public abstract class Animal
    {
        public String Especie { get; set; }
        public String Apelido { get; set; }

        public Animal(String apelido)
        {
            this.Apelido = apelido;
        }

        public abstract void EmitirSom();
    }
}
