﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    public class Elefante : Animal
    {
        public Elefante(string apelido) : base(apelido)
        {
        }

        public override void EmitirSom()
        {
            Console.WriteLine("Som de Elefante");
        }
    }
}
