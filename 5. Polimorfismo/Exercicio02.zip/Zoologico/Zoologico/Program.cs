﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    class Program
    {
        static void Main(string[] args)
        {
            Zoologico zoo = new Zoologico();
            zoo.RazaoSocial = "Zoologico de Araraquara";
            zoo.Animais = new List<Animal>();

            Animal leao = new Leao("Simba");
            Animal preguica = new Preguica("Cid");
            Animal elefante = new Elefante("Dumbo");

            zoo.Animais.Add(leao);
            zoo.Animais.Add(elefante);

            Veterinario veterinario = new Veterinario();
            veterinario.Nome = "Richard";

            veterinario.Examinar(preguica);
            veterinario.Examinar(zoo.Animais);

            Console.ReadKey();
        }
    }
}
