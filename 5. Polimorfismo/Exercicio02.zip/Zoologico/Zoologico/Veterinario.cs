﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    public class Veterinario
    {
        public String Nome { get; set; }
        public String Cnpj { get; set; }

        public void Examinar(Animal animal)
        {
            Console.WriteLine("{0} examinado!", animal.Apelido);
            animal.EmitirSom();
        }
        
        public void Examinar(List<Animal> animais)
        {
            foreach(Animal animal in animais)
            {
                Examinar(animal);
            }
            // Loop tradicional:
            /*
             * for (int i = 0; i < animais.Count; i++)
             * {
             *    Animal animal = animais[i];
             *    Examinar(animal);
             * }
             */
        }
    }
}
