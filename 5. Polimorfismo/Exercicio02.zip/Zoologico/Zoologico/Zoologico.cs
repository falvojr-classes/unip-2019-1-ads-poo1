﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    public class Zoologico
    {
        public String RazaoSocial { get; set; }
        public List<Animal> Animais { get; set; }
    }
}
