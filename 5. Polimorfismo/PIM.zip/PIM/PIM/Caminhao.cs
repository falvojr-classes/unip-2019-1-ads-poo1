﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    public class Caminhao : Veiculo
    {
        public Caminhao() : base(TipoVeiculo.CAMINHAO) { }

        public override double AliquotaIpva()
        {
            return 1.5;
        }
    }
}
