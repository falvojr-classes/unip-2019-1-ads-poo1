﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    public class Moto : Veiculo
    {
        public Moto() : base(TipoVeiculo.MOTO) { }

        public override double AliquotaIpva()
        {
            return 2.0;
        }
    }
}
