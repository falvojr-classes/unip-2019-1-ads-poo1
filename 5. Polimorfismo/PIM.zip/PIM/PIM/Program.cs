﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    class Program
    {
        static void Main(string[] args)
        {
            Veiculo carro = new Carro();
            carro.Valor = 20000;
            carro.Ano = 2000;

            Veiculo moto = new Moto();
            moto.Valor = 5000;
            moto.Ano = 2000;

            Veiculo caminhao = new Caminhao();
            caminhao.Valor = 50000;
            caminhao.Ano = 1990;

            List<Veiculo> frota = new List<Veiculo>();
            frota.Add(carro);
            frota.Add(moto);
            frota.Add(caminhao);

            foreach (Veiculo veiculo in frota)
            {
                double ipva = veiculo.CalcularIpva();
                Console.WriteLine("{0}: {1}", veiculo.Tipo, ipva);
            }
            Console.ReadKey();
        }
    }
}
