﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    public enum TipoVeiculo
    {
        MOTO = 1,
        CARRO = 2,
        CAMINHAO = 3
    }
}
