﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIM
{
    public abstract class Veiculo
    {
        public string Modelo { get; set; }
        public string Marca { get; set; }
        public string Renavam { get; set; }
        public string Chassi { get; set; }
        public string Placa { get; set; }
        public double Valor { get; set; }
        public int Ano { get; set; }
        public TipoVeiculo Tipo { get; set; }

        public Veiculo(TipoVeiculo tipo)
        {
            this.Tipo = tipo;
        }

        public double CalcularIpva()
        {
            double ipva = 0;
            if (DateTime.Now.Year - Ano < 20)
            {
                ipva = (AliquotaIpva() / 100) * Valor;
            }
            return ipva;
        }

        public abstract double AliquotaIpva();
    }
}
