﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoNP1
{
    class Aluno
    {
        public string Nome { get; set; }
        public string Cpf { get; set; }
        public string DataNascimento { get; set; }
        public Turma Turma { get; set; }

        public void Matricular(Turma turma)
        {
            this.Turma = turma;
        }
    }
}
