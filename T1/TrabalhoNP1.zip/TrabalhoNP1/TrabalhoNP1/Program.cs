﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoNP1
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Steven Spielberg, nascido em 18/12/1946 e 
             * portador do CPF 000000000-00, ocupa o cargo 
             * de diretor, com um salário de R$ 6.000,00; */
            Funcionario steven = new Funcionario();
            steven.Nome = "Steven Spielberg";
            steven.Cpf = "000000000-00";
            steven.Cargo = "Diretor";
            steven.Salario = 6000.00;

            /* Andrew Tanenbaum, nascido em 16/03/1944 e 
             * portador do CPF 111111111-11, é contratado 
             * para o cargo de professor, com um salário de 
             * R$ 5.000,00; */
            Funcionario andrew = new Funcionario();
            andrew.Nome = "Andrew Tanenbaum";
            andrew.Cpf = "111111111-11";
            andrew.Cargo = "Professor";
            andrew.Salario = 5000.00;

            /* Alan Turing, nascido em 13/06/1912 e portador 
             * do CPF 101010101-10, se matricula na turma 
             * POO1 no período da manhã;*/
            Aluno alan = new Aluno();
            alan.Nome = "Alan Turing";
            alan.Cpf = "101010101-10";
            alan.DataNascimento = "13/06/1912";

            /*Nicola Tesla, nascido em 10/07/1956 e portador 
             * do CPF 33333333333, se matricula na turma POO1 
             * no período da manhã;*/
            Aluno tesla = new Aluno();
            tesla.Nome = "Nicola Tesla";
            tesla.Cpf = "33333333333";
            tesla.DataNascimento = "10/07/1956";

            /*Stephen Hawking, nascido em 08/01/1942 e portador
             * do CPF 888888888-88, se matricula na turma POO1 
             * no período da manhã.*/
            Aluno hawking = new Aluno();
            hawking.Nome = "Stephen Hawking";
            hawking.Cpf = "888888888-88";
            hawking.DataNascimento = "08/01/1942";

            // Criar uma turma para os relacionamentos
            Turma poo1 = new Turma("POOI");
            poo1.Periodo = "Manha";

            // Relacionr o Professor "Andrew" com a Turma POO1
            andrew.Turma = poo1;
            // Relacionar os Alunos com a Turma POO1
            poo1.Matricular(alan);
            tesla.Matricular(poo1);
            andrew.Matricular(hawking);

            Console.WriteLine("Professor {0} ({1})", andrew.Nome, andrew.Turma.Sigla);
            Console.WriteLine("Aluno {0} ({1})", alan.Nome, alan.Turma.Sigla);
            Console.WriteLine("Aluno {0} ({1})", tesla.Nome, tesla.Turma.Sigla);
            Console.WriteLine("Aluno {0} ({1})", hawking.Nome, hawking.Turma.Sigla);
            Console.ReadKey();
        }
    }
}
