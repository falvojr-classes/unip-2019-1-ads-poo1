﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabalhoNP1
{
    class Turma
    {
        public string Sigla { get; set; }
        public string Periodo { get; set; }

        public Turma()
        {

        }

        public Turma(string sigla)
        {
            this.Sigla = sigla;
        }

        public void Matricular(Aluno aluno)
        {
            aluno.Turma = this;
        }
    }
}
